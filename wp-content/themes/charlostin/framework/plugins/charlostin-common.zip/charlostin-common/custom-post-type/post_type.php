<?php
// register post type Portfolio
add_action( 'init', 'register_charlostin_Portfolio' );
function register_charlostin_Portfolio() {
    
    $labels = array( 
        'name' => __( 'Portfolio', 'charlostin' ),
        'singular_name' => __( 'Portfolio', 'charlostin' ),
        'add_new' => __( 'Add New Portfolio', 'charlostin' ),
        'add_new_item' => __( 'Add New Portfolio', 'charlostin' ),
        'edit_item' => __( 'Edit Portfolio', 'charlostin' ),
        'new_item' => __( 'New Portfolio', 'charlostin' ),
        'view_item' => __( 'View Portfolio', 'charlostin' ),
        'search_items' => __( 'Search Portfolio', 'charlostin' ),
        'not_found' => __( 'No Portfolio found', 'charlostin' ),
        'not_found_in_trash' => __( 'No Portfolio found in Trash', 'charlostin' ),
        'parent_item_colon' => __( 'Parent Portfolio:', 'charlostin' ),
        'menu_name' => __( 'Portfolio', 'charlostin' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Portfolio',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Portfolio', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Portfolio', $args );
}
add_action( 'init', 'create_Type_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'charlostin' ),
    'singular_name' => __( 'Type', 'charlostin' ),
    'search_items' =>  __( 'Search Type','charlostin' ),
    'all_items' => __( 'All Type','charlostin' ),
    'parent_item' => __( 'Parent Type','charlostin' ),
    'parent_item_colon' => __( 'Parent Type:','charlostin' ),
    'edit_item' => __( 'Edit Type','charlostin' ), 
    'update_item' => __( 'Update Type','charlostin' ),
    'add_new_item' => __( 'Add New Type','charlostin' ),
    'new_item_name' => __( 'New Type Name','charlostin' ),
    'menu_name' => __( 'Type','charlostin' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Portfolio',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}

add_action( 'init', 'register_charlostin_Events' );
function register_charlostin_Events() {
    
    $labels = array( 
        'name' => __( 'Events', 'charlostin' ),
        'singular_name' => __( 'Events', 'charlostin' ),
        'add_new' => __( 'Add New Events', 'charlostin' ),
        'add_new_item' => __( 'Add New Events', 'charlostin' ),
        'edit_item' => __( 'Edit Events', 'charlostin' ),
        'new_item' => __( 'New Events', 'charlostin' ),
        'view_item' => __( 'View Events', 'charlostin' ),
        'search_items' => __( 'Search Events', 'charlostin' ),
        'not_found' => __( 'No Events found', 'charlostin' ),
        'not_found_in_trash' => __( 'No Events found in Trash', 'charlostin' ),
        'parent_item_colon' => __( 'Parent Events:', 'charlostin' ),
        'menu_name' => __( 'Events', 'charlostin' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Events',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Events', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Events', $args );
}
add_action( 'init', 'create_EventsType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_EventsType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'EventsType', 'charlostin' ),
    'singular_name' => __( 'EventsType', 'charlostin' ),
    'search_items' =>  __( 'Search EventsType','charlostin' ),
    'all_items' => __( 'All EventsType','charlostin' ),
    'parent_item' => __( 'Parent EventsType','charlostin' ),
    'parent_item_colon' => __( 'Parent EventsType:','charlostin' ),
    'edit_item' => __( 'Edit EventsType','charlostin' ), 
    'update_item' => __( 'Update EventsType','charlostin' ),
    'add_new_item' => __( 'Add New EventsType','charlostin' ),
    'new_item_name' => __( 'New EventsType Name','charlostin' ),
    'menu_name' => __( 'EventsType','charlostin' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Events',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));

}

add_action( 'init', 'register_charlostin_Gallery' );
function register_charlostin_Gallery() {
    
    $labels = array( 
        'name' => __( 'Gallery', 'charlostin' ),
        'singular_name' => __( 'Gallery', 'charlostin' ),
        'add_new' => __( 'Add New Gallery', 'charlostin' ),
        'add_new_item' => __( 'Add New Gallery', 'charlostin' ),
        'edit_item' => __( 'Edit Gallery', 'charlostin' ),
        'new_item' => __( 'New Gallery', 'charlostin' ),
        'view_item' => __( 'View Gallery', 'charlostin' ),
        'search_items' => __( 'Search Gallery', 'charlostin' ),
        'not_found' => __( 'No Gallery found', 'charlostin' ),
        'not_found_in_trash' => __( 'No Gallery found in Trash', 'charlostin' ),
        'parent_item_colon' => __( 'Parent Gallery:', 'charlostin' ),
        'menu_name' => __( 'Gallery', 'charlostin' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Gallery',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Gallery', 'type2' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Gallery', $args );
}
add_action( 'init', 'create_Type2_hierarchical2_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type2_hierarchical2_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type2', 'charlostin' ),
    'singular_name' => __( 'Type2', 'charlostin' ),
    'search_items' =>  __( 'Search Type2','charlostin' ),
    'all_items' => __( 'All Type2','charlostin' ),
    'parent_item' => __( 'Parent Type2','charlostin' ),
    'parent_item_colon' => __( 'Parent Type2:','charlostin' ),
    'edit_item' => __( 'Edit Type2','charlostin' ), 
    'update_item' => __( 'Update Type2','charlostin' ),
    'add_new_item' => __( 'Add New Type2','charlostin' ),
    'new_item_name' => __( 'New Type2 Name','charlostin' ),
    'menu_name' => __( 'Type2','charlostin' ),
  );     

// Now register the taxonomy

  register_taxonomy('type2',array('Gallery',), array(
    'hierarchical2' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type2' ),
  ));

}

add_action( 'init', 'register_charlostin_Spa' );
function register_charlostin_Spa() {
    
    $labels = array( 
        'name' => __( 'Spa', 'charlostin' ),
        'singular_name' => __( 'Spa', 'charlostin' ),
        'add_new' => __( 'Add New Spa', 'charlostin' ),
        'add_new_item' => __( 'Add New Spa', 'charlostin' ),
        'edit_item' => __( 'Edit Spa', 'charlostin' ),
        'new_item' => __( 'New Spa', 'charlostin' ),
        'view_item' => __( 'View Spa', 'charlostin' ),
        'search_items' => __( 'Search Spa', 'charlostin' ),
        'not_found' => __( 'No Spa found', 'charlostin' ),
        'not_found_in_trash' => __( 'No Spa found in Trash', 'charlostin' ),
        'parent_item_colon' => __( 'Parent Spa:', 'charlostin' ),
        'menu_name' => __( 'Spa', 'charlostin' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Spa',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Spa', 'style' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Spa', $args );
}
add_action( 'init', 'create_Style_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Style_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Style', 'charlostin' ),
    'singular_name' => __( 'Style', 'charlostin' ),
    'search_items' =>  __( 'Search Style','charlostin' ),
    'all_items' => __( 'All Style','charlostin' ),
    'parent_item' => __( 'Parent Style','charlostin' ),
    'parent_item_colon' => __( 'Parent Style:','charlostin' ),
    'edit_item' => __( 'Edit Style','charlostin' ), 
    'update_item' => __( 'Update Style','charlostin' ),
    'add_new_item' => __( 'Add New Style','charlostin' ),
    'new_item_name' => __( 'New Style Name','charlostin' ),
    'menu_name' => __( 'Style','charlostin' ),
  );     

// Now register the taxonomy

  register_taxonomy('style',array('Spa',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'style' ),
  ));

}

?>