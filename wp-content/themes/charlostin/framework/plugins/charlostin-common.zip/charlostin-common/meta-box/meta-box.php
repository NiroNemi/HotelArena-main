<?php
/**
 * Plugin Name: Meta Box
 * Plugin URI:  https://metabox.io
 * Description: Create custom meta boxes and custom fields in WordPress.
 * Version:     5.3.3
 * Author:      MetaBox.io
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: meta-box
 * Domain Path: /languages/
 *
 * @package Meta Box
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
	register_activation_hook( __FILE__, 'rwmb_check_php_version' );

	/**
	 * Display notice for old PHP version.
	 */
	function rwmb_check_php_version() {
		if ( version_compare( phpversion(), '5.3', '<' ) ) {
			die( esc_html__( 'Meta Box requires PHP version 5.3+. Please contact your host to upgrade.', 'meta-box' ) );
		}
	}




	require_once dirname( __FILE__ ) . '/inc/loader.php';
	$rwmb_loader = new RWMB_Loader();
	$rwmb_loader->init();


	add_filter( 'rwmb_meta_boxes', function ( $meta_boxes ) {

	$prefix = '_cmb_';


  // Open Code



    $meta_boxes[] = array(
        'id'         => 'page_setting',
        'title'      => 'Page Setting',
        'pages'      => array('page'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('hb_room'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Room Exerpt',
                'desc' => 'Input Room Exerpt',
                'id'   => $prefix . 'room_excerpt',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Room Facility',
                'desc' => 'Input Room Facility',
                'id'   => $prefix . 'room_facility',
                'type'    => 'textarea',
            ),
           array(
            'name' => 'Sidebar',
            'desc' => 'Select type show sidebar',
            'id'   => $prefix . 'sidebar_select',
            'type'    => 'select',
            'options'   => array(
                array( 'value' => 'default', 'name' => 'Default' ),
                array( 'value' => 'contact', 'name' => 'Contact Form'),
                array( 'value' => 'link', 'name' => 'External Links'),
                ),
            'placeholder'     => 'Select Sidebar',
                ),
           array(
                'name' => 'Booking Link',
                'desc' => 'Input Booking Link',
                'id'   => $prefix . 'booking_link',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('portfolio'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Image',
                'desc' => 'Image Upload',
                'default' => '',
                'id' => $prefix . 'single_image',
                'type' => 'file'
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('Events'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Time',
                'desc' => 'start time title',
                'id'   => $prefix . 'events_time',
                'type'    => 'text',
            ),
            array(
                'name' => 'Time Subtitle',
                'desc' => 'start time subtitle',
                'id'   => $prefix . 'events_subtime',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Location',
                'desc' => 'Organization Position title',
                'id'   => $prefix . 'events_location',
                'type'    => 'text',
            ),
            array(
                'name' => 'Location Subtitle',
                'desc' => 'Organization Position subtitle',
                'id'   => $prefix . 'events_sublocation',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Schedule',
                'desc' => 'Hourly Schedule title',
                'id'   => $prefix . 'events_schedule',
                'type'    => 'text',
            ),
            array(
                'name' => 'Schedule Subtitle',
                'desc' => 'Hourly Schedule subtitle',
                'id'   => $prefix . 'events_subschedule',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Events Image',
                'desc' => 'Events Image Upload',
                'default' => '',
                'id' => $prefix . 'events_image',
                'type' => 'file'
            ),
            array(
                'name' => 'Intended Time 1',
                'desc' => 'Intended Time 1',
                'id'   => $prefix . 'events_intended1',
                'type'    => 'text',
            ),
            array(
                'name' => 'Intended Time 2',
                'desc' => 'Intended Time 2',
                'id'   => $prefix . 'events_intended2',
                'type'    => 'text',
            ),
            array(
                'name' => 'Events Exerpt',
                'desc' => 'Events Exerpt',
                'id'   => $prefix . 'events_excerpt',
                'type'    => 'textarea',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('Gallery'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Image',
                'desc' => 'Image Upload',
                'default' => '',
                'id' => $prefix . 'gallery_image',
                'type' => 'file'
            ),
            array(
                'name' => 'Number Of Photos',
                'desc' => 'Input Number Of Photos',
                'id'   => $prefix . 'gallery_number',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('Spa'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Price',
                'desc' => 'cost of treatment',
                'id'   => $prefix . 'spa_price',
                'type'    => 'text',
            ),
            array(
                'name' => 'Excerpt',
                'desc' => 'excerpts of the content',
                'id'   => $prefix . 'spa_excerpt',
                'type'    => 'textarea',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Video Post',
                'desc' => 'Input link video show in index',
                'id'   => $prefix . 'single_video',
                'type'    => 'text',
            ),
            array(
                'name' => 'Image',
                'desc' => 'Image Upload',
                'default' => '',
                'id' => $prefix . 'single_image',
                'type' => 'file'
            ),
        )
    );
    



// End Code



    return $meta_boxes;
});
}
