<?php
/**
 * The template for displaying content single room.
 *
 * This template can be overridden by copying it to yourtheme/wp-hotel-booking/content-single-room.php.
 *
 * @author  ThimPress, leehld
 * @package WP-Hotel-Booking/Templates
 * @version 1.6
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit(); ?>

<?php
/**
 * hotel_booking_before_single_product hook
 */
$sidebar_select = get_post_meta(get_the_ID(),'_cmb_sidebar_select', true);
$booking_link = get_post_meta(get_the_ID(),'_cmb_booking_link', true);

do_action( 'hotel_booking_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form();

	return;
} ?>




 <!--================Breadcrumb Area =================-->
        <section class="breadcrumb_area">
        	<div class="container">
        		<div class="breadcrumb_text">
        			<h2>Single Room</h2>
        			<div class="link">
        				<a class="active" href="<?php echo esc_url(home_url('/')); ?>">Home</a>
        				<a>Room</a>
        				<a>Room Details</a>
        			</div>
        		</div>
        	</div>
        </section>
        <!--================End Breadcrumb Area =================-->
        
        <!--================Room Details Area =================-->
        <section class="room_details_area p_100 hb_single_room">
        	<div class="container">
        		<div class="row room_details_inner">
        			<div class="col-lg-8">
        				<?php
	/**
	 * hotel_booking_before_loop_room_summary hook
	 */
	do_action( 'hotel_booking_before_single_room' );
	?>
        				<div class="room_details">
        				<?php
		/**
		 * hotel_booking_single_room_title hook
		 */
		do_action( 'hotel_booking_single_room_title' );

		/**
		 * hotel_booking_loop_room_price hook
		 */
		do_action( 'hotel_booking_loop_room_price' );

		/**
		 * hotel_booking_single_room_gallery hook
		 */
		do_action( 'hotel_booking_single_room_gallery' );

		/**
		 * hotel_booking_single_room_infomation hook
		 */
		do_action( 'hotel_booking_single_room_infomation' );
		?>	
        			</div>
        			<?php
/**
 * hotel_booking_after_single_product hook
 */
do_action( 'hotel_booking_after_single_product' ); ?>
        			</div>
<?php if($sidebar_select =='default'){ ?> 
        			<div class="col-lg-4">
        				<div class="book_room_area">
        					<div class="night_price">
        						<h5> $135 / Night</h5>
        					</div>
							<?php echo do_shortcode("[hotel_booking2]"); ?>
						</div>
       					<div class="book_box">
       						<div class="media">
       							<div class="d-flex">
       								<i class="flaticon-sale"></i>
       							</div>
       							<div class="media-body">
       								<h4>Your Book</h4>
       								<p>Your cart is empty</p>
       							</div>
       						</div>
       					</div>
       					<div class="share_hotel">
       						<h4>Share this hotel room</h4>
       					</div>
        			</div>
<?php }elseif($sidebar_select =='contact'){ ?>
					<div class="col-lg-4">
        				<div class="book_room_area">
        					<div class="night_price">
        						<h6>$150 <span>/ Night</span></h6>
        					</div>
							<div class="drop_query">
								<h4>Drop us your query</h4>
								<?php echo do_shortcode('[contact-form-7 id="505" title="contact sidebar"]'); ?>
							</div>
						</div>
       					<div class="book_box">
       						<div class="media">
       							<div class="d-flex">
       								<i class="flaticon-sale"></i>
       							</div>
       							<div class="media-body">
       								<h4>Your Book</h4>
       								<p>Your cart is empty</p>
       							</div>
       						</div>
       					</div>
       					<div class="share_hotel">
       						<h4>Share this hotel room</h4>
       					</div>
        			</div>
<?php }elseif($sidebar_select =='link'){ ?>
					<div class="col-lg-4">
							<div class="book_room_area">
								<div class="night_price">
									<h6>$150 <span>/ Night</span></h6>
								</div>
								<div class="link_text">
									<p>For book this room, click below button and make payment</p>
									<a class="main_btn" href="<?php echo htmlspecialchars_decode(esc_attr($booking_link));?>">Book this room</a>
								</div>
							</div>
								<div class="book_box">
									<div class="media">
										<div class="d-flex">
											<i class="flaticon-sale"></i>
										</div>
										<div class="media-body">
											<h4>Your Book</h4>
											<p>Your cart is empty</p>
										</div>
									</div>
								</div>
								<div class="share_hotel">
									<h4>Share this hotel room</h4>
								</div>
						</div>
<?php } ?>
        		</div>
        	</div>
        </section>

